﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace harfayirimi
{
    class Program
    {
        // Sesli harfleri saydırdım
        static int Sesliharfler(string input)
        {
            // Sesli harfler
            char[] Sesli = { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
            int count = 0;


            foreach (char c in input)
            {
                if (Array.Exists(Sesli, Sesl => Sesl == c))
                {
                    count++;
                }
            }
            return count;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("yazacağınız yazıdaki sesli harf sayısını bulalım...");
            string userInput = Console.ReadLine();


            int Harfsesli = Sesliharfler(userInput);


            Console.WriteLine($"toplam {Harfsesli} sesli harf var.");
            Console.ReadKey();
        }
    }
}
