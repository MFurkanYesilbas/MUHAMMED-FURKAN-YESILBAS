﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringToNumber
{
    class Program
    {
        static int harfayirma(string input)
        {
            string sayi = string.Empty;
            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    sayi += c;
                }
            }
return sayi == string.Empty ? 0 : int.Parse(sayi);
        }

        static void Main(string[] args)
        {
        Console.WriteLine("harfle karışık cümle yazabilirsiniz: ");
        string userInput = Console.ReadLine();
        int result = harfayirma(userInput);
        Console.WriteLine($"Girilen cümle içerisindeki rakamlardan oluşan sayı: {result}");
        Console.ReadKey();
        }
    }
}